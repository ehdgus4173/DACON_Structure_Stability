import sys
import numpy as np
import pandas as pd
from pathlib import Path

import os

_IS_KAGGLE = os.environ.get('KAGGLE_MODE') == '1' or os.path.exists('/kaggle')

if _IS_KAGGLE:
    _FEAT_DIR    = Path(os.environ.get('FEAT_OUT_DIR', '/kaggle/working/features'))
    PROJECT_ROOT = Path('/kaggle/working')
    sys.path.append(str(Path(__file__).resolve().parent.parent.parent))
    try:
        from config import PHYS_COLS_V2
    except ImportError:
        PHYS_COLS_V2 = []
else:
    sys.path.append(str(Path(__file__).resolve().parent.parent.parent))
    from config import PROJECT_ROOT, PHYS_COLS_V2
    _FEAT_DIR = PROJECT_ROOT / 'features' 


# ================================================================
# 2세대 피처 메타 정보
# ================================================================

# 2세대 피처 전체 목록 (CSV에 저장되는 컬럼, PHYS_COLS_V2의 상위 집합)
ENGINEERED_COLS = [
    'FS_overturning',
    'kern_ratio',
    'top_heavy_index',
    'p_delta_eccentricity',
    'effective_eccentricity',
    'eccentric_combined',
    'base_stability_index',
    'lateral_moment_approx',
    'slenderness_approx',
]


# ================================================================
# 2세대 구조공학 피처 추가 함수 (찬호 코드 이식)
# ================================================================
def add_physics_features(data: pd.DataFrame) -> pd.DataFrame:
    """
    extract_base.py에서 추출한 1세대 피처를 입력받아 구조공학 이론 피처 9종 추가.

    입력 컬럼 필요:
        t_footprint_area, f_cx_offset, f_cy_offset,
        f_mass_upper_ratio, f_cy_norm, f_tilt_angle,
        f_height_ratio, f_width_ratio, t_left_mass_ratio

    추가되는 컬럼 (ENGINEERED_COLS):
        FS_overturning, kern_ratio, top_heavy_index,
        p_delta_eccentricity, effective_eccentricity,
        eccentric_combined, base_stability_index,
        lateral_moment_approx, slenderness_approx
    """
    d = data.copy()

    # 기초 폭 추정 (t_footprint_area의 제곱근으로 근사)
    B = np.sqrt(d['t_footprint_area'].clip(lower=1e-6))

    # 피처 1. 전도 안전율 (FS < 1.5 = Danger)
    d['FS_overturning'] = (B / 2) / (d['f_cx_offset'].abs() + 1e-6)

    # 피처 2. Kern Ratio (> 1.0 = Unstable)
    d['kern_ratio'] = d['f_cx_offset'].abs() / (B / 6 + 1e-6)

    # 피처 3. Top-Heavy Index (상부질량 × 높이 비율)
    d['top_heavy_index'] = d['f_mass_upper_ratio'] * d['f_cy_norm']

    # 피처 4. P-delta 편심
    d['p_delta_eccentricity'] = (
        np.sin(np.radians(d['f_tilt_angle'])) * d['f_cy_norm']
    )

    # 피처 5. 유효 편심 (P-delta 포함)
    d['effective_eccentricity'] = (
        d['f_cx_offset'].abs() + d['p_delta_eccentricity'].abs()
    )

    # 피처 6. 복합 편심 (x, y 방향 편차 합성)
    d['eccentric_combined'] = np.sqrt(
        d['f_cx_offset']**2 + d['f_cy_offset']**2
    )

    # 피처 7. 기저 안정 지수
    d['base_stability_index'] = (
        d['t_footprint_area'] / (d['eccentric_combined'] + 1e-6)
    )

    # 피처 8. 횡방향 모멘트 근사
    d['lateral_moment_approx'] = d['t_left_mass_ratio'] * d['f_cy_norm']

    # 피처 9. 세장비 근사
    d['slenderness_approx'] = d['f_height_ratio'] / (d['f_width_ratio'] + 1e-6)

    return d


def main(args=None):
    # ----------------------------------------------------------------
    # 1. combined_features_v2.csv 로드
    # ----------------------------------------------------------------
    v2_path = PROJECT_ROOT / 'features' / 'combined_features_v2.csv'
    if not v2_path.exists():
        raise FileNotFoundError(
            f"combined_features_v2.csv 없음: {v2_path}\n"
            "먼저 extract_base.py (Step 1) 실행 필요"
        )

    df = pd.read_csv(v2_path)
    print(f"[1] combined_features_v2.csv 로드: {df.shape[0]}행, {df.shape[1]}컬럼")

    # ----------------------------------------------------------------
    # 2. 필요 컬럼 존재 확인
    # ----------------------------------------------------------------
    required = [
        't_footprint_area', 'f_cx_offset', 'f_cy_offset',
        'f_mass_upper_ratio', 'f_cy_norm', 'f_tilt_angle',
        'f_height_ratio', 'f_width_ratio', 't_left_mass_ratio'
    ]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"필요 컬럼 누락: {missing}\nextract_base.py 재실행 필요")
    print(f"[2] 필요 컬럼 확인 완료")

    # ----------------------------------------------------------------
    # 3. 2세대 피처 계산 및 병합
    # ----------------------------------------------------------------
    df = add_physics_features(df)
    print(f"[3] 2세대 피처 {len(ENGINEERED_COLS)}종 추가 → 총 {df.shape[1]}컬럼")
    for col in ENGINEERED_COLS:
        null_cnt = df[col].isnull().sum()
        print(f"    {col:<30} null={null_cnt}")

    # ----------------------------------------------------------------
    # 4. 저장
    # ----------------------------------------------------------------
    output_dir = PROJECT_ROOT / 'features'
    output_dir.mkdir(exist_ok=True)
    out_path = output_dir / 'combined_features_v3.csv'
    df.to_csv(out_path, index=False)

    print(f"\n[4] 저장 완료: {out_path}")
    print(f"    최종 shape: {df.shape}")
    print(f"\n[모델 입력 피처 ({len(PHYS_COLS_V2)}종, PHYS_COLS_V2 from config.py)]")
    for col in PHYS_COLS_V2:
        tag = '(2세대)' if col in ENGINEERED_COLS else '(1세대)'
        print(f"    {col:<30} {tag}")

    print("\n✅ combined_features_v3.csv 생성 완료.")


if __name__ == '__main__':
    main()
